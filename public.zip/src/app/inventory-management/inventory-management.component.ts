import { Component } from '@angular/core';

@Component({
  selector: 'app-inventory-management',
  imports: [],
  templateUrl: './inventory-management.component.html',
  styleUrl: './inventory-management.component.scss'
})
export class InventoryManagementComponent {

}
