import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-device-managment',
  imports: [RouterOutlet],
  templateUrl: './device-managment.component.html',
  styleUrl: './device-managment.component.scss'
})
export class DeviceManagmentComponent {

}
