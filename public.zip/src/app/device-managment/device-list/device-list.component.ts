import { Component } from '@angular/core';

@Component({
  selector: 'app-device-list',
  imports: [],
  templateUrl: './device-list.component.html',
  styleUrl: './device-list.component.scss'
})
export class DeviceListComponent {

}
