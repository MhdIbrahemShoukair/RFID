import { Component } from '@angular/core';

@Component({
  selector: 'app-device-rfiddata',
  imports: [],
  templateUrl: './device-rfiddata.component.html',
  styleUrl: './device-rfiddata.component.scss'
})
export class DeviceRFIDDataComponent {

}
