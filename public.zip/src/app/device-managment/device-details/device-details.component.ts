import { Component } from '@angular/core';

@Component({
  selector: 'app-device-details',
  imports: [],
  templateUrl: './device-details.component.html',
  styleUrl: './device-details.component.scss'
})
export class DeviceDetailsComponent {

}
